$(document).ready(function(){
    $('.carousel-item:first-child').addClass('active');

});